import {View, Text} from 'react-native';
import React from 'react';
import DrawerNavigator from '../DRAWER/DrawerNavigator';

const BottomHome = () => {
  return (
    <DrawerNavigator />
    // <View>
    //   <Text>BottomHome</Text>
    // </View>
  );
};

export default BottomHome;
