import {View, Text, SafeAreaView} from 'react-native';
import React from 'react';
import DrawerNavigator from '../DRAWER/DrawerNavigator';

const Search = () => {
  return (
    <DrawerNavigator />
    // <SafeAreaView>
    //   <View>
    //     <Text>Search ...</Text>
    //   </View>
    // </SafeAreaView>
  );
};

export default Search;
