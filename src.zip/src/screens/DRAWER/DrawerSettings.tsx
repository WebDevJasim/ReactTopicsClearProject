import {View, Text} from 'react-native';
import React from 'react';

const DrawerSettings = () => {
  return (
    <View>
      <Text>DrawerSettings</Text>
    </View>
  );
};

export default DrawerSettings;
