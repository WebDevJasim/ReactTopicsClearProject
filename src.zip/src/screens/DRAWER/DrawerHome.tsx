import {View, Text} from 'react-native';
import React from 'react';

const DrawerHome = () => {
  return (
    <View>
      <Text>DrawerHome</Text>
    </View>
  );
};

export default DrawerHome;
